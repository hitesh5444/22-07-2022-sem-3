var name = prompt ("What's Your Name:-");
document.write(name);